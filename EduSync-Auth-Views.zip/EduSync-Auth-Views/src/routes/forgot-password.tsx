import { createFileRoute } from '@tanstack/react-router'
import AuthView from '../components/AuthView'

export const Route = createFileRoute('/forgot-password')({
  head: () => ({ meta: [{ title: 'Reset your password | EduSync' }] }),
  component: AuthPage,
})

function AuthPage() {
  return <AuthView mode="forgot-password" />
}
