import { createFileRoute } from '@tanstack/react-router'
import AuthView from '../components/AuthView'

export const Route = createFileRoute('/register')({
  head: () => ({ meta: [{ title: 'Create an account | EduSync' }] }),
  component: AuthPage,
})

function AuthPage() {
  return <AuthView mode="register" />
}
