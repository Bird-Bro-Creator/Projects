import { createFileRoute } from '@tanstack/react-router'
import AuthView from '../components/AuthView'

export const Route = createFileRoute('/login')({
  head: () => ({ meta: [{ title: 'Sign in | EduSync' }] }),
  component: AuthPage,
})

function AuthPage() {
  return <AuthView mode="login" />
}
