import { Link } from '@tanstack/react-router'
import { useState } from 'react'
import type { FormEvent } from 'react'

type AuthMode = 'login' | 'register' | 'forgot-password'

const content = {
  login: {
    title: 'Sign in to EduSync',
    description: 'Enter your email address and password.',
    button: 'Sign in',
    feedback: 'The form passed validation. Sign-in is unavailable in this preview.',
  },
  register: {
    title: 'Create your EduSync account',
    description: 'Enter your details to get started.',
    button: 'Create account',
    feedback: 'The form passed validation. Account creation is unavailable in this preview.',
  },
  'forgot-password': {
    title: 'Reset your password',
    description: 'Enter the email address associated with your account.',
    button: 'Request reset link',
    feedback: 'The email address passed validation. Sending reset links is unavailable in this preview.',
  },
} satisfies Record<AuthMode, Record<string, string>>

const inputClass =
  'mt-1.5 block w-full rounded-xl border border-[var(--chip-line)] bg-[var(--foam)] px-3 py-2.5 text-base font-normal focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--palm)]'
const linkClass = 'font-semibold underline focus-visible:outline-2 focus-visible:outline-offset-2'

export default function AuthView({ mode }: { mode: AuthMode }) {
  const { title, description, button, feedback } = content[mode]
  const [status, setStatus] = useState('')

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    event.currentTarget.reset()
    setStatus(feedback)
  }

  return (
    <main className="page-wrap py-10 sm:py-16">
      <section
        aria-labelledby="auth-title"
        className="island-shell mx-auto w-full max-w-md rounded-3xl p-6 sm:p-8"
      >
        <h1 id="auth-title" className="display-title text-3xl font-bold tracking-tight sm:text-4xl">
          {title}
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-[var(--sea-ink-soft)]">
          {description}
        </p>
        <p className="mt-2 text-sm text-[var(--sea-ink-soft)]">
          Preview only. Use sample details.
        </p>

        {/* Fields stay unnamed so a native submission cannot serialize the preview values. */}
        <form className="mt-6 space-y-4" onSubmit={handleSubmit} onChange={() => setStatus('')}>
          {mode === 'register' && (
            <label className="block text-sm font-semibold">
              Full name
              <input className={inputClass} autoComplete="name" pattern={'.*\\S.*'} required />
            </label>
          )}

          <label className="block text-sm font-semibold">
            Email address
            <input
              className={inputClass}
              type="email"
              autoComplete={mode === 'login' ? 'username' : 'email'}
              required
            />
          </label>

          {mode !== 'forgot-password' && (
            <label className="block text-sm font-semibold">
              Password
              <input
                className={inputClass}
                type="password"
                autoComplete={mode === 'register' ? 'new-password' : 'current-password'}
                minLength={mode === 'register' ? 8 : undefined}
                aria-describedby={mode === 'register' ? 'password-hint' : undefined}
                required
              />
              {mode === 'register' && (
                <span id="password-hint" className="mt-1.5 block font-normal text-[var(--sea-ink-soft)]">
                  Use at least 8 characters.
                </span>
              )}
            </label>
          )}

          {mode === 'login' && (
            <div className="text-right text-sm">
              <Link to="/forgot-password" className={linkClass}>
                Forgot your password?
              </Link>
            </div>
          )}

          <button
            type="submit"
            className="w-full cursor-pointer rounded-xl bg-[var(--sea-ink)] px-4 py-2.5 text-sm font-bold text-[var(--foam)] hover:opacity-90 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--palm)]"
          >
            {button}
          </button>
        </form>

        <p role="status" className="text-sm leading-relaxed text-[var(--sea-ink-soft)] [&:not(:empty)]:mt-4">
          {status}
        </p>

        <p className="mt-6 border-t border-[var(--line)] pt-4 text-sm text-[var(--sea-ink-soft)]">
          {mode === 'login' ? (
            <>
              New to EduSync?{' '}
              <Link to="/register" className={linkClass}>Create an account</Link>
            </>
          ) : (
            <Link to="/login" className={linkClass}>Back to sign in</Link>
          )}
        </p>
      </section>
    </main>
  )
}
