# EduSync Auth Views

This bundle contains the React component and TanStack route files for sign-in, registration, and password recovery. The source files are laid out at their intended paths in EduSync. They use EduSync's existing Tailwind styles and are meant to run inside that app.

